package com.jcdecaux.recruiting.developpers.domain.service;

public interface InfosService {

	String getCurrentVersion();
}
