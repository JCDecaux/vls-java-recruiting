Bonjour,

Pour ce test qui servira de support de discussion, nous vous demandons de réaliser une API REST permettant de :

* créer des développeurs,
* modifier les informations d'un développeur,
* créer des langages de programmation,
* associer un langage de programmation à un développeur,
* lister les développeurs ayant comme compétence un langage de programmation en particulier.

Pour réaliser cela, vous avez 2 options :
* soit vous vous basez sur une structure de projet simpliste, celle fournit,
* soit en mode from-scratch en utilisant les outils de votre choix.

Quel que soit votre choix, vous devrez utiliser Java 8 et ne devrez pas y consacrer plus de 3 ou 4h.

Enfin le livrable devra nous être renvoyé 24h avant l’entretien.

Merci et bon code :)

